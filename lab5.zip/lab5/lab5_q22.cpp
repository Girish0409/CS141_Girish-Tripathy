//include the library
#include <iostream>
using namespace std;

//use main function
int main () { 
	int N ; //declaring the varible 
		cout << "Welcome to question no. 22" << endl; //Welcome
		cout << "Input the N" << endl ; //asking user for number
		cin >> N ; //assigning values
		cout << "Printing all natural number from 1 to " << N << endl ; 
	int i = 1 ;
	while ( i <= N ) //using while loop
		{ cout << i << endl ;  i++ ; }
return 0;
}


