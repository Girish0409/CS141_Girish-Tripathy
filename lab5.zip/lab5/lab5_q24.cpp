//include the library
#include <iostream>
using namespace std;

//use main function
int main () { 
	 
		cout << "Welcome to question no. 24" << endl; //Welcome
		cout << "Printing a to z" <<endl ; //printing
	char charVar = 'a' ; //defining variable and assigning value to it
	while ( charVar <= 'z' )
		{ cout << charVar << endl; charVar++ ; }
return 0;
}
