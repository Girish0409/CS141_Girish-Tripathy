//include the library
#include <iostream>
using namespace std;

//use main function
int main () { 
		cout << "Welcome to question no. 26" << endl; //Welcome
		cout << "Printing even number from 1 to 100" << endl ; // Printing
	int i = 1 ; //declaring variable
	while ( i <= 100 ) //looping
		{ cout << i << endl ; i += 2 ; }
return 0;
}
		
