//include the library
#include <iostream>
using namespace std;

//use main function
int main () { 
	int N ; //declaring the varible 
		cout << "Welcome to question no. 23" << endl; //Welcome
		cout << "Input your N " << endl ; //asking user for N
		cin >> N ; //assigning values
		cout << "Printing values from " << N << " to 1 " <<endl ; //Result
	int i = N ;
	while ( i >= 1 ) { 
 		cout << i << endl;  //printing values
		i-- ; }
return 0;
} 
	
		
